package main

type List[T any] struct {
	elems []T
}

// Task: create chaining methods Add, Update, Pop, Delete
func main() {

}
