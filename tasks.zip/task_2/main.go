package main

type Map[K comparable, V any] struct {
}

// Task: create Map[K, V] with methods Add(K, V), Delete(K), Update(K, V), Get(K)
func main() {

}
