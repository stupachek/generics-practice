package main

// Task: create Counter with method Next(). Counter expected to support all kinds of int and its inherit types
func main() {

}
